// this file used to generate route path ('/en-US/index')
