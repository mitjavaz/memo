// this file used to generate route path ('/zh-CN/index')
