export default {
  // Example locale
}
