import Button from './Button'
import { withInstall } from '../utils/components'

withInstall(Button)

export const _ButtonComponent = Button

export default Button
