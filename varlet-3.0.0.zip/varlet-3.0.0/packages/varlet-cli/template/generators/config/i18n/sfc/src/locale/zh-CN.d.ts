import type { Pack } from '../../types'

declare const zhCN: Pack

export default zhCN
