import { Pack } from './index'

// for component's internal
export default {
  // Button component
  button: '按钮',
} as Pack
