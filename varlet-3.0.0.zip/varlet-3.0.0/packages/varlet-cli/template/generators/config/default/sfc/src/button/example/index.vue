<script setup>
import VaButton from '..'
import { AppType } from '@varlet/cli/client'
</script>

<template>
  <app-type>基本使用</app-type>
  <va-button>起步</va-button>

  <app-type>修改颜色</app-type>
  <va-button color="#03A9F4">起步</va-button>
</template>
