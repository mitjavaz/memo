<script setup>
import VaButton from '..'
</script>

<template>
  <va-button color="#03A9F4">起步</va-button>
</template>
