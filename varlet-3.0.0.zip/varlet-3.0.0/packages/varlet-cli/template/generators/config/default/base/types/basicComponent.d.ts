import type { App } from 'vue'

export class BasicComponent {
  static name: string

  static install(app: App): void
}
