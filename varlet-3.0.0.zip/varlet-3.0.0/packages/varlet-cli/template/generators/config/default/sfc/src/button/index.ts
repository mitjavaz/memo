import Button from './Button.vue'
import { withInstall } from '../utils/components'

withInstall(Button)

export const _ButtonComponent = Button

export default Button
