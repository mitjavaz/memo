<script setup>
import VaButton from '..'
</script>

<template>
  <va-button>起步</va-button>
</template>
