export default {
  downloadResources: '下载资源',
}
