export default {
  downloadResources: 'Download Resources',
}
