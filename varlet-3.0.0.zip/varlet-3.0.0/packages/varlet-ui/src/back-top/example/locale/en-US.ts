export default {
  basicUsage: 'Basic Usage',
}
