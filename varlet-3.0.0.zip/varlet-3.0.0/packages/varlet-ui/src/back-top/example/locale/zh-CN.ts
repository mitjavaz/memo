export default {
  basicUsage: '基本使用',
}
