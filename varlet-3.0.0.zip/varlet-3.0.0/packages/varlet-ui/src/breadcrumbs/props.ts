export const props = {
  separator: {
    type: String,
    default: '/',
  },
}
