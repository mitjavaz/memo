export const props = {
  offset: [Number, String],
  vertical: Boolean,
}
