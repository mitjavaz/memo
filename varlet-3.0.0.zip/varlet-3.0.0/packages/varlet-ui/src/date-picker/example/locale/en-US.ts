export default {
  basicUsage: 'Basic Usage',
  monthPicker: 'Month Picker',
  multiple: 'Multiple',
  range: 'Range',
  dateLimit: 'Date Limit',
  year: '',
  month: '',
  divider: '-',
}
