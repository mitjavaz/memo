export default {
  basicUsage: 'Basic Usage',
  customStyle: 'Custom Background Color',
  addTitleSlot: 'Add Title Slot',
  title: 'Title',
  addLeftAndRightSlot: 'Add Left And Right Slot',
  option: 'OPTION',
  search: 'search',
  round: 'Use Border Radius',
  custom: 'Custom Content',
}
