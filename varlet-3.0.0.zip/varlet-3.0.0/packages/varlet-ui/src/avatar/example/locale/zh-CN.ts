export default {
  avatarSize: '头像尺寸',
  avatarShape: '头像形状',
  fitMode: '填充模式',
  fontSize: '文字自适应',
  backgroundColor: '背景颜色',
  avatarHorizontalGroup: '头像水平分组',
  avatarVerticalGroup: '头像垂直分组',
  avatarHoverable: '头像可悬停',
}
