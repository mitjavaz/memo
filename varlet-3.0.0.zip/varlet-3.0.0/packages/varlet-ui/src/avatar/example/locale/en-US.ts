export default {
  avatarSize: 'Avatar Size',
  avatarShape: 'Avatar Shape',
  fitMode: 'Fit Mode',
  fontSize: 'Text Adaptive',
  backgroundColor: 'Background Color',
  avatarHorizontalGroup: 'Avatar Horizontal Group',
  avatarVerticalGroup: 'Avatar Vertical Group',
  avatarHoverable: 'Avatar Hoverable',
}
