export default {
  basicUsage: '基本使用',
  showIcon: '显示图标',
  showDesc: '显示描述',
  showBorder: '显示边框',
  content: '这是单元格',
  description: '描述',
  list: '用作列表项',
}
