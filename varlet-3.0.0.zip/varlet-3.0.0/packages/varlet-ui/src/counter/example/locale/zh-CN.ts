export default {
  basicUsage: '基本使用',
  range: '设置取值范围',
  step: '设置步长',
  toFixed: '保留小数',
  disabled: '禁用',
  readonly: '只读',
  lazyChange: '异步变更',
  size: '设置尺寸',
  validate: '字段校验',
  validateMessage: '请设置大于5的值',
}
