export default {
  basicUsage: 'Basic Usage',
  range: 'Set Value Range',
  step: 'Set Step',
  toFixed: 'Decimal Length',
  disabled: 'Disabled',
  readonly: 'Readonly',
  lazyChange: 'Asynchronous Change',
  size: 'Set Size',
  validate: 'Validate',
  validateMessage: 'Please set a value greater than 5',
}
