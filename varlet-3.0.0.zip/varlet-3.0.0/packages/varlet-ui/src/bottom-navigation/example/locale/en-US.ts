export default {
  basicUsage: 'Basic Usage',
  matchByName: 'Match By Name',
  showBadge: 'Show Badge',
  customColor: 'Custom Color',
  changeEvent: 'Change Event',
  clickEvent: 'Click Event',
  fab: 'Fab',
  label: 'label',
}
