export default {
  basicUsage: '基本使用',
  matchByName: '通过名称匹配',
  showBadge: '徽标提示',
  customColor: '自定义颜色',
  changeEvent: '监听切换事件',
  clickEvent: '监听点击事件',
  fab: '悬浮按钮',
  label: '标签',
}
