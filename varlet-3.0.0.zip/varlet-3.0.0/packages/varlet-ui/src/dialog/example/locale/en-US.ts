export default {
  functionCall: 'Function Call',
  basicUsage: 'Basic Usage',
  modifyTitle: 'Modify Title',
  hideButton: 'Hide Button',
  handleUserBehavior: 'Handle User Behavior',
  asyncClose: 'Asynchronous closing',
  componentCall: 'Component Call',
  title: 'Beat It',
  message: "Don't Wanna See No Blood, Don't Be A Macho Man",
  customSlots: 'Custom Slots',
  asyncCloseProgress: 'Asynchronous shutdown in progress',
}
