export default {
  functionCall: '函数调用',
  basicUsage: '基本使用',
  modifyTitle: '修改标题',
  hideButton: '隐藏按钮',
  handleUserBehavior: '处理用户行为',
  asyncClose: '异步关闭',
  componentCall: '组件调用',
  title: '兰亭序',
  message: '兰亭临帖 行书如行云流水',
  customSlots: '自定义插槽',
  asyncCloseProgress: '正在异步关闭',
}
