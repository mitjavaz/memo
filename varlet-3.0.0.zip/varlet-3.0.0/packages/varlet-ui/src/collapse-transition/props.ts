export const props = {
  expand: Boolean,
}
