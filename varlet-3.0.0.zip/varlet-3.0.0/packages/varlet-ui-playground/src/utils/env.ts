export const usePreviewVersion = import.meta.env.DEV || __APP_ENABLE_PREVIEW__
