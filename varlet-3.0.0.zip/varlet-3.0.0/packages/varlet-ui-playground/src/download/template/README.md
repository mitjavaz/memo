# Varlet Playground Demo

To start:

```sh
npm install
npm run dev

# if using yarn:
yarn
yarn dev
```
